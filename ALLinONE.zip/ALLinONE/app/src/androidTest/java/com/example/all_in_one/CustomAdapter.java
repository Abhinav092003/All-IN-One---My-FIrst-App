package com.example.all_in_one;

import junit.framework.TestCase;

public class CustomAdapter extends TestCase {



}
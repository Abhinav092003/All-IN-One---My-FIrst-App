package com.example.all_in_one;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity5 extends AppCompatActivity {
    private final String[] question ={ "1. Gandhi was the first Prime Minister of India","2. Cricket is the National sport of India","3. Christianity is the third biggest religion in India"
            ,"4. India drives on the right side of the road." ,"5. India shares it's longest border with Bangladesh" ,"6. No Indian has ever won the Nobel Peace Prize" ,"7. The River Indus originates in India",
            "8. India does not have any Active Volcanoes" ,"9. Andaman and Nicobar islands are closer to Thailand than to mainland India." ,"10. India is larger than Argentina by land area"};

    private final boolean[] answer = {false,false ,true ,false ,true ,false ,false ,false ,true ,true };
    private int score =0;
    Button yes;
    Button no;
    Button submit;
    private TextView textView3,textview24;




    private int index =0;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);
        yes = findViewById(R.id.button11);
        no = findViewById(R.id.button12);
        textView3=findViewById(R.id.textView3);
        textView3.setText(question[index]);

        textview24 = findViewById(R.id.textView24);
        submit=findViewById(R.id.button13);








    }



    public void yes(View view)
    {



            if (index <= question.length-1)
            {

                if (answer[index])
                {
                    score++;
                }
                index++;
                if (index<=question.length-1)
                {
                    textView3.setText(question[index]);
                }



            }

            else
        {
            Toast.makeText(this, "Restart To Play", Toast.LENGTH_SHORT).show();
        }


    }

    public void no(View view)
    {

        if (index <= question.length-1)
        {
            if (!answer[index])
            {
                score++;
            }
            index++;

            if (index<=question.length-1)
            {
                textView3.setText(question[index]);
            }




        }
        else
        {
            Toast.makeText(this, "Restart To Play", Toast.LENGTH_SHORT).show();
        }






    }

    public void submit(View view)
    {
        Toast.makeText(this, "Submitted☑️", Toast.LENGTH_SHORT).show();
        textview24.setText("Your Score Is: " +score+"/"+question.length);
    }


}
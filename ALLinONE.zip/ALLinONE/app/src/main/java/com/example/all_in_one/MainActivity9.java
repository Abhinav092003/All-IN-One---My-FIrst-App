package com.example.all_in_one;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity9 extends AppCompatActivity {
    private String[] Questions = {"1. First ODI (Cricket) in India was played in Ahemadabad.","2. Goa is famous for not producing coconut.","3. Polo was originated in Assam.",
    "4. The Khalsa was born in 1699.","5. Lata Mangeshkar won the Padma Bhushan in 1960.","6. Shakespeare wrote 37 plays.","7. The first captain of the first ODI Indian team was Sunil Gavaskar..",
    "8. Baseball originated in Australia.","9. Red and green lights are used to indicate foul in ice hockey.","10. Ostrich's eyes are smaller than its brain."};
    private boolean[] Answers ={true,true,false,true,false,true,false,false,false,false};
    int score=0;
    Button yes;
    Button no;
    private TextView textView16;
    private int index=0;
    private TextView textView17;
    Button button2;
    
    

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main9);
        yes =findViewById(R.id.button6);
        no =findViewById(R.id.button7);
        textView16 =findViewById(R.id.textView16);
        textView16.setText(Questions[index]);
        textView17=findViewById(R.id.textView17);
        button2=findViewById(R.id.button2);
    }
    
    public void yes(View view)
    {
        if (index<=Questions.length-1)
        {
            if (Answers[index])
            {
                score++;


            }
            index++;
            if (index<=Questions.length-1)
            {
                textView16.setText(Questions[index]);
            }

        }
        else{
            Toast.makeText(this, "Restart To Play", Toast.LENGTH_SHORT).show();
        }


    }

    public void no(View view)
    {
        if (index<=Questions.length-1)
        {
            if (!Answers[index])
            {
                score++;

            }
            index++;
            if (index<=Questions.length-1)
            {
                textView16.setText(Questions[index]);
            }

        }
        else{
            Toast.makeText(this, "Restart To Play", Toast.LENGTH_SHORT).show();
        }
    }

    public void submit(View view)
    {
        Toast.makeText(this, "Submitted"+"✅", Toast.LENGTH_SHORT).show();
        textView17.setText("Your Score Is: "+score+ "/" +Questions.length);
    }
}
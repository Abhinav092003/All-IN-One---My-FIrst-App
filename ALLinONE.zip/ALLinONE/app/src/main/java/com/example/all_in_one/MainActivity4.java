package com.example.all_in_one;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity4 extends AppCompatActivity {
    Button youtube;
    Button instagram;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        youtube=findViewById(R.id.button4);
        instagram=findViewById(R.id.button5);


        youtube.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity4.this, "My Life", Toast.LENGTH_SHORT).show();
                gotoUrl("https://youtube.com/channel/UCeaQbm77fFoHKXKNXptk3cQ");
            }


            private void gotoUrl(String s) {
                Uri uri =Uri.parse(s);
                startActivity(new Intent(Intent.ACTION_VIEW,uri));
            }


        });

    }


    public void instagram(View view)
    {
        Toast.makeText(this, "raj__abhinav", Toast.LENGTH_SHORT).show();
        gotoUrl("https://www.instagram.com/invites/contact/?i=1r56hbmol6ha2&utm_content=lrfstd8");
    }

    private void gotoUrl(String s) {
        Uri uri =Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW,uri));
    }


}



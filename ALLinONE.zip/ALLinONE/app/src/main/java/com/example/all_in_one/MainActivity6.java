package com.example.all_in_one;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity6 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);
    }
    
    public void indiaquiz(View view)
    {
        Toast.makeText(this, "Opening India Quiz", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this,MainActivity5.class);
        startActivity(intent);
    }

    public void gkquiz1(View view)
    {
        Toast.makeText(this, "Openig GK Quiz-1", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this,MainActivity9.class);
        startActivity(intent);
    }
    public void bce(View view)
    {
        Toast.makeText(this, "Openig BCE", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this,MainActivity10.class);
        startActivity(intent);
    }
}
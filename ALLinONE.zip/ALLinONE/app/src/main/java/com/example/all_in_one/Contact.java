package com.example.all_in_one;

public class Contact {
    public int sno;
    public String name;
    public String phonenumber;
    public String description;

    Contact(int sno ,String name ,String phonenumber ,String description)
    {
        this.sno=sno;
        this.name=name;
        this.phonenumber=phonenumber;
        this.description=description;
    }

}

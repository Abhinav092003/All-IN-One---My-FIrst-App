package com.example.all_in_one;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity10 extends AppCompatActivity {
    Button no,yes,submit;
    TextView textView21,textView23;
    int score=0;
    private int index=0;
    private String[] question={"1. A building can be mainly divided into 3 components?","2. D.P.C (Damp Proof Course) is mainly laid on footing?"
    , "3. Floor in a building Is laid below plinth?" ,"4. level below window called sill level?","5. Wall is mainly of 2 types?","6. Shear wall is used to resist lateral forces like severe wind?"
    ,"7. 5 types of parapets are there?" ,"8. Building finishes are not considered as components of a building?","9. Skylight is a type of window."
    ,"10. The outer projection on the tread of a stair is Nosing?"};
    private boolean[] answer ={true,false,false,true,true,true,false,false,true,true};



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main10);
        no=findViewById(R.id.button9);
        yes=findViewById(R.id.button18);
        submit=findViewById(R.id.button14);

        textView21=findViewById(R.id.textView21);
        textView23=findViewById(R.id.textView23);
        textView21.setText(question[index]);


    }
    public void yes(View view)
    {
        if (index<=question.length-1) {
            if (answer[index]) {
                score++;
            }

            index++;

            if (index <= question.length - 1) {

                textView21.setText(question[index]);
            }
            else {
                Toast.makeText(this, "Restart To Play", Toast.LENGTH_SHORT).show();
            }
        }


    }


    public void no(View view)
    {
        if (index<=question.length-1) {

            if (!answer[index]) {
                score++;
            }
            index++;
            if (index <= question.length - 1) {
                textView21.setText(question[index]);
            }


             else {
                Toast.makeText(this, "Restart To Play", Toast.LENGTH_SHORT).show();
            }
        }


    }

    public void submit(View view)
    {
        Toast.makeText(this, "Submitted☑️", Toast.LENGTH_SHORT).show();
        textView23.setText("Your Score is: "+score+ "/" +question.length);
    }
}
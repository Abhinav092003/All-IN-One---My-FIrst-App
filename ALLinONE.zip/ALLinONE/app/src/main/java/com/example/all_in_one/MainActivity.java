package com.example.all_in_one;

import android.Manifest;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.DexterError;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.PermissionRequestErrorListener;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import com.karumi.dexter.listener.single.PermissionListener;

import java.util.List;

public class MainActivity extends AppCompatActivity {



    private Switch switch3;

    private MediaPlayer mediaPlayer;




    @Override
    protected void onResume() {
        super.onResume();
        mediaPlayer.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        mediaPlayer.pause();


    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mediaPlayer.stop();
        mediaPlayer.release();
    }






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        switch3= findViewById(R.id.switch3);
        boolean Switch = switch3.isChecked();
        switch3.setChecked(true);


        mediaPlayer = MediaPlayer.create(this ,R.raw.audio );
        mediaPlayer.setLooping(true);
        mediaPlayer.start();


        switch3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (switch3.isChecked())
                {

                    mediaPlayer.start();
                }



                else
                {
                    mediaPlayer.pause();

                }

            }
        });







    }





    public void calender(View view) {
        Toast.makeText(this, "Opening Calender", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, MainActivity2.class);
        startActivity(intent);
    }

    public void about(View view) {
        Toast.makeText(this, "Made By ABHINAV", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, MainActivity3.class);
        startActivity(intent);
    }



    public void quiz(View view)
    {
        Toast.makeText(this, "Opening Quiz", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this,MainActivity6.class);
        startActivity(intent);
    }
    
    public void map(View view)
    {
        Toast.makeText(this, "Coming Soon", Toast.LENGTH_SHORT).show();
    }


    

    public void number(View view)
    {
        Toast.makeText(this, "Opening Social Media", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this,MainActivity7.class);
        startActivity(intent);
    }
    
    
    public void youtube(View view)
    {
        Toast.makeText(this, "Opening Social Media", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this,MainActivity4.class);
        startActivity(intent);
    }

    public void horoscope(View view)
    {
        Toast.makeText(this, "Coming Soon", Toast.LENGTH_SHORT).show();
    }

    public void music(View view)
    {
        Toast.makeText(this, "Opening Music Player", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(this , MainActivity8.class);
        startActivity(intent);

    }







    }






